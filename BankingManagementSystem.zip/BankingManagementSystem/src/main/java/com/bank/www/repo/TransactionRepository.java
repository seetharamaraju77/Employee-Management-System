package com.bank.www.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import jakarta.transaction.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction, Long>
{
	List<Transaction> FindByFromAccountorToAccount (String from , String to);
}
