package com.bank.www.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.www.entity.Account;
import com.bank.www.entity.Transaction;
import com.bank.www.repo.AccountRepository;
import com.bank.www.repo.TransactionRepository;

@Service

public class AccountService 
{
	@Autowired
	private AccountRepository accountrepository;
	
	@Autowired
	private TransactionRepository transactionrepository;
	
	public Account createAccount(Account account)
	{
		account.setBalance(0.0);
		
		return accountrepository.save(account);
	}
	
	public Account deposit (String accountNumber, double amount)
	{
		Account account = accountrepository.FindByAccountNumber(accountNumber)
				.orElseThrow(()-> new RuntimeException("Account not found"));
		
		account.setBalance(account.getBalance() + amount);
		
		transactionrepository.save(new Transaction(
				null, DEPOSIT, amount, LocalDateTime.now(),
				
				accountNumber, accountNumber
				));
				
		return accountrepository.save(account);
	}
	
}
