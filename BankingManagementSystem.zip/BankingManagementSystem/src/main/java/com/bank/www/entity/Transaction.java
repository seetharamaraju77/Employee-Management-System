package com.bank.www.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class Transaction 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private String type;	
	private double amount;
	private LocalDateTime transactionDate;
	
	private String FromAccount;
	private String ToAccount;
}
