package com.bank.www.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class Account 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private Long AccountId;
	
	private String accountHolderName; 
	
	@Column(unique = true)
	
	private String AccountNumber;
	
	private double balance;
}
